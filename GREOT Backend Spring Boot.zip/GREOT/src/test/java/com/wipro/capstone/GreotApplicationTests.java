package com.wipro.capstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreotApplicationTests {

	@Test
	void contextLoads() {
	}

}


